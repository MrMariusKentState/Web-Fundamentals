



$(document).ready(function() {

    $('#first').click (function(){
        $('#ninja0').toggle();

    })

    $('#second').click (function(){
        $('#ninja1').toggle();

    })

    $('#third').click (function(){
        $('#cat2').toggle();

    })

    $('#fourth').click (function(){
        $('#cat3').toggle();

    })

    $('#fifth').click (function(){
        $('#cat4').toggle();

    })

})

// $('img').click(function(){
//     $(this).hide("slow")
// })
    
// $('button').click(function() {
//     $('img').show()
// })

// })