// console.log("Javascript Working!")

$(function(){
    // $('h1').hide();
    $('#testing').hide();
    $('#change-bg').click(function(){
        $('h2').addClass('bg-color');
    })
    $('#btnGreen').click(function(){
        $('.project').addClass('para-style');
    })
    $('#btnRemove').click(function(){
        $('.project').removeClass('para-style');
    })
    $('#btnCarrot').click(function(){
        $('#carrot-garden').append('<img src="carrot.gif" class="carrot" alt="">')
    })
    $('#btnTree').click(function(){
        $('#carrot-garden').append('<img src="tree.png" class="carrot" alt="">')
    })
    $('#btn-slide-up').click(function(){
        $('#img-dog').slideUp(800);
    })
    $('#btn-slide-down').click(function(){
        $('#img-dog').slideDown();
    })
    $('#img-dog').click(function(){
        $(this).fadeOut();
        $(this).fadeIn();
    })
    $('#btn-dark').click(function(){
        $('body').toggleClass('flip');
      });
    $('#move-around').click(function(){
        var fly1=$('#fly-one');
        var fly2=$('#fly-two');
        var frog=$('#frog');
      
        for(var i=0;i<=4;i++){
            fly1.animate({
                top:300,
            }, "slow")
            fly1.animate({
                top:0
            }, "slow")
            fly2.animate({
                top:500
            }, "slow")
            fly2.animate({
                top:10
            }, "slow")
           frog.animate({
                right:300
            }, "slow")
            frog.animate({
                right:0
            }, "slow")
        }
      })



})